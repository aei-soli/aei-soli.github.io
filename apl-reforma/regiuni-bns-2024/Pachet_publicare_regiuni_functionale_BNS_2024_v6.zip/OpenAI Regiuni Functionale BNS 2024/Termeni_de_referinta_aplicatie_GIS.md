# Termeni de referință

## Aplicație GIS pentru analiza geografiei funcționale a Republicii Moldova

**Versiune:** 1.0  
**Data:** 28 august 2026  
**Statut:** document de proiectare pentru prototip și dezvoltare ulterioară

## 1. Context

Studiul geografiei funcționale utilizează datele RPL 2024 privind populația și navetismul, limite UAT APL I, rețeaua rutieră, centre urbane și servicii. Analiza trebuie să poată fi repetată atunci când apar date noi și explorată online fără software GIS instalat.

Aplicația nu este un instrument de trasare automată a limitelor administrative. Ea este o platformă de analiză, transparență metodologică și comparare de scenarii.

## 2. Obiectiv general

Realizarea unei aplicații web publice care:

- afișează FUA candidate, microregiuni și regiuni funcționale;
- separă clar fluxurile observate de atribuirile modelate;
- permite modificarea parametrilor și recalcularea scenariilor;
- calculează autocontenția, retenția navetismului și accesibilitatea;
- oferă exporturi GIS și tabele reproductibile;
- poate fi publicată prin GitHub și Cloudflare.

## 3. Grupuri de utilizatori

1. **Public/decident:** vizualizare, căutare, explicații, comparație și descărcare.
2. **Analist:** configurarea parametrilor, rularea scenariilor și exportul rezultatelor.
3. **Administrator de date:** încărcarea versiunilor, validarea legăturilor CUATM și publicarea unei versiuni aprobate.

## 4. Principii obligatorii

- UAT APL I este unitatea teritorială de bază.
- Apartenența la raion are pondere zero și nu este barieră.
- Teritoriul din regiunea transnistreană și municipiul Bender este exclus din delimitare.
- Fluxurile peste Nistru se pot afișa separat numai dacă sunt observate.
- Datele observate și inferența sunt câmpuri distincte în date, legendă și interfață.
- Nicio geometrie lipsă nu este inventată; UAT fără poligon rămâne punct și intră în calcule.
- Fiecare scenariu păstrează parametrii, sursele, data, autorul și indicatorii de validare.
- Rezultatele nu pot fi prezentate ca limite oficiale fără aprobare instituțională.

## 5. Arhitectura recomandată

### 5.1 Nivel public — aplicație statică

- MapLibre GL JS pentru randarea hărții în browser;
- HTML/CSS/JavaScript sau o aplicație TypeScript ușoară;
- GeoJSON pentru prototip; PMTiles/vector tiles pentru producție;
- publicare în GitHub, livrare prin Cloudflare Pages/CDN;
- fără autentificare pentru vizualizarea rezultatelor aprobate.

### 5.2 Nivel analitic — serviciu de calcul

- Python cu GeoPandas, NetworkX/igraph, NumPy și un motor de rutare;
- API FastAPI cu lucrări asincrone;
- stocare PostgreSQL/PostGIS pentru versiunea multiutilizator;
- coadă de lucrări pentru scenarii costisitoare;
- rezultate versionate în GeoPackage/Parquet/PMTiles.

### 5.3 Nivel profesional GIS

- GeoPackage și proiect QGIS pentru QA, corectarea geometriilor, tipărire și analiză avansată;
- QGIS nu este eliminat și rămâne instrumentul de referință al analistului;
- QGIS Server poate fi evaluat ulterior pentru WMS/WFS, dar nu este necesar prototipului static.

## 6. De ce MapLibre și nu numai QGIS

MapLibre și QGIS îndeplinesc roluri diferite:

| Cerință | MapLibre | QGIS Desktop |
|---|---|---|
| utilizare direct în browser | da | nu |
| publicare pe GitHub/Cloudflare static | da | nu direct |
| instalare pentru public | nu | da |
| filtre, scenarii și interfață personalizată | foarte potrivit | limitat la interfața desktop/pluginuri |
| analiză GIS profesională | limitată | foarte bună |
| editare și control cartografic | limitate | foarte bune |
| automatizare server | necesită backend separat | QGIS Server necesită infrastructură server |

Decizia este o combinație: **QGIS pentru producție și control GIS; MapLibre pentru publicare și interacțiune web**. Dacă s-ar utiliza numai QGIS, publicarea ar necesita qgis2web cu funcții limitate sau un QGIS Server administrat permanent, care nu se potrivește la fel de bine cu găzduirea statică actuală.

## 7. Module funcționale

### 7.1 Vizualizare publică

- selectarea nivelului: FUA, microregiuni, regiuni funcționale;
- prag FUA 10/15/20%;
- comutatoare pentru centre, fluxuri principale, fluxuri peste Nistru și limite UAT;
- legendă dinamică și explicație metodologică;
- identificare prin clic și fișă de indicatori;
- căutare după denumire și CUATM;
- afișarea populației, centrului, timpului, distanței, motivului atribuirii și autocontenției;
- descărcare GeoPackage, GeoJSON, CSV, PDF și nota metodologică.

### 7.2 Comparator de scenarii

- două hărți sincronizate sau glisor înainte/după;
- matrice de trecere a UAT între scenarii;
- diferențe de populație, suprafață, navetiști reținuți și autocontenție;
- evidențierea UAT care își schimbă centrul;
- export al comparației.

### 7.3 Constructor de scenarii

Parametri minimi:

- prag FUA: 5–30%;
- numărul minim/maxim de centre;
- numărul regiunilor mari: 5–9;
- ponderi pentru flux, timp, distanță, servicii și masă economică;
- timp maxim orientativ: 30–90 minute;
- cerință de contiguitate;
- ancore obligatorii/opționale;
- includere separată a fluxurilor peste Nistru;
- prag de suprimare a fluxurilor mici pentru publicare.

Sistemul trebuie să afișeze avertisment dacă ponderile nu însumează 100%, dacă un centru nu este conectat sau dacă o regiune devine discontinuă.

### 7.4 Validare și jurnal

Pentru fiecare rulare:

- numărul UAT și populația totală reconciliată;
- UAT fără poligon sau rută;
- componentele teritoriale pentru fiecare zonă;
- ponderea atribuirilor observate/modelate;
- retenția navetismului;
- autocontenția rezidenților și locurilor de muncă;
- distribuția timpilor și distanțelor;
- lista parametrilor și versiunilor surselor;
- hash pentru fișierele de intrare și rezultate.

## 8. Specificația modelului analitic

### 8.1 FUA

`share(i,c) = commuters(i,c) / employed_residents(i)`

O UAT intră dacă ponderea depășește pragul și aparține componentei conectate la nucleu. Se publică ponderea exactă și motivul includerii.

### 8.2 Microregiuni

Pentru UAT care nu trec pragul observat:

`score(i,c) = wF × flow_share + wT × exp(-time/τ) + wM × centre_mass + wS × service_score`

Alocarea finală trebuie să respecte contiguitatea. Valorile implicite ale ponderilor vor fi calibrate pe versiunea BNS-commuting-v1, dar rămân editabile.

### 8.3 Regiuni mari

Se agregă matricea OD la microregiuni și se maximizează fluxurile bidirecționale interne, sub condiții de contiguitate și ancore. Sistemul trebuie să poată optimiza:

- autocontenția totală;
- echilibrul minim al populației, dacă utilizatorul îl activează;
- penalizarea timpilor excesivi;
- numărul de regiuni.

Echilibrarea administrativă este o opțiune de scenariu, nu un criteriu funcțional implicit.

## 9. Model de date minim

### UAT

`cuatm`, `name`, `population_2024`, `geometry_status`, `employed_total`, `same_commune`, `micro_id`, `region_id`, `centre`, `assignment_reason`, `time_min`, `distance_km`, `route_method`, `fua_share_10/15/20`.

### Flux

`origin_cuatm`, `destination_cuatm`, `workers`, `same_micro`, `same_region`, `cross_river_flag`, `year`, `source_version`.

### Scenariu

`scenario_id`, `name`, `status`, `created_at`, `created_by`, `input_version`, `parameters_json`, `validation_json`, `published_at`.

## 10. API propus pentru etapa dinamică

- `GET /api/v1/datasets` — versiuni disponibile;
- `GET /api/v1/scenarios` — scenarii publicate;
- `GET /api/v1/scenarios/{id}` — metadate și indicatori;
- `GET /api/v1/scenarios/{id}/tiles/{z}/{x}/{y}` — vector tiles;
- `GET /api/v1/scenarios/{id}/units/{cuatm}` — fișa UAT;
- `POST /api/v1/scenarios` — creare rulare;
- `GET /api/v1/jobs/{id}` — progres;
- `POST /api/v1/scenarios/{id}/publish` — publicare cu drept de administrator;
- `GET /api/v1/scenarios/{id}/export?format=gpkg|geojson|csv|pdf` — export.

## 11. Cerințe nefuncționale

- încărcarea interfeței sub 3 secunde pe conexiune fixă obișnuită;
- interacțiune fluentă pentru minimum 900 UAT și 10.000 fluxuri agregate;
- design adaptiv pentru desktop, tabletă și telefon;
- navigare prin tastatură, contrast accesibil și texte alternative;
- limba română implicit, structură pregătită pentru engleză;
- niciun secret sau token în codul public GitHub;
- API cu rate limiting, validarea fișierelor și roluri pentru modificări;
- jurnale și copii de siguranță pentru date și scenarii;
- teste automate pentru reconciliere, contiguitate și indicatori;
- atribuirea surselor și respectarea licențelor.

## 12. Publicare și securitate

Prototipul static se publică dintr-un director GitHub prin Cloudflare Pages. GeoJSON-urile trebuie să fie pe același domeniu. Pentru producție, fișierele mari se transformă în PMTiles și se livrează prin CDN.

Backendul analitic nu trebuie găzduit în GitHub Pages. El va rula separat, fără acces direct la sistemul de fișiere public și fără date individuale. Se publică numai fluxuri agregate; se stabilește un prag de confidențialitate împreună cu BNS.

## 13. Livrabile

### Etapa 1 — prototip static

- hartă MapLibre cu cele trei niveluri și pragurile FUA;
- căutare UAT și fișă de indicatori;
- comutatoare pentru centre/fluxuri;
- descărcări și documentație;
- GeoPackage și proiect QGIS;
- cod sursă publicabil.

### Etapa 2 — model parametric

- backend de calcul și API;
- constructor de scenarii;
- comparator;
- autentificare pentru analiști;
- export automat și jurnal.

### Etapa 3 — producție

- PostGIS, vector tiles/PMTiles și monitorizare;
- traducere în engleză;
- testare cu utilizatori și accesibilitate;
- protocol de actualizare anuală și administrare.

## 14. Criterii de acceptare pentru prototip

1. Sunt reconciliate 897 UAT și 2.409.207 locuitori.
2. Cele cinci UAT fără poligon apar ca punct și în tabel.
3. Niciuna dintre cele 32 de microregiuni și șapte regiuni nu este discontinuă.
4. FUA 10/15/20 folosesc numitorul corect și nu aplică umplere recursivă.
5. Harta separă observat/modelat și prezintă sursele.
6. Utilizatorul poate identifica o UAT și vedea centrul, timpul, distanța și metoda traseului.
7. Fișierele GIS și tabelele sunt descărcabile.
8. Aplicația funcționează în ultimele două versiuni Chrome, Edge, Firefox și Safari.
9. Nu există erori JavaScript la încărcare și controalele sunt utilizabile pe ecran mic.
10. Versiunea metodei și data surselor sunt vizibile.

## 15. Întrebări care necesită decizie înaintea etapei dinamice

- pragul de confidențialitate pentru publicarea fluxurilor mici;
- dacă rezultatul oficial trebuie să păstreze exact șapte regiuni sau să compare 5–9;
- dacă se introduce o constrângere explicită de echilibru demografic;
- sursa rutieră oficială care poate fi reutilizată și condițiile de licență ASD;
- rolurile instituționale pentru aprobarea și publicarea scenariilor;
- frecvența de actualizare și bugetul de găzduire al backendului.
