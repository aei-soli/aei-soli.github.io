# Prototip web Leaflet/Canvas

Acest director poate fi copiat într-un site GitHub/Cloudflare. Fișierul principal este `index.html`; datele publicabile sunt în `data/`.

Fișierul `index.html` conține datele GIS încorporate și poate fi deschis direct prin `file://`. Redarea Leaflet/Canvas procesează local cele 897 UAT și evită dependența de lucrători GeoJSON care poate bloca poligoanele în anumite configurații Chrome.

Înainte de publicare:

1. păstrați atribuirea BNS, GHSL și OpenStreetMap;
2. confirmați cu BNS pragul de confidențialitate al fluxurilor;
3. înlocuiți serviciul public `tile.openstreetmap.org` cu un furnizor de tile-uri potrivit traficului estimat;
4. publicați GeoJSON-urile pe același domeniu cu aplicația;
5. verificați consola browserului și toate controalele pe desktop și telefon.

Prototipul folosește GeoJSON încorporat și Leaflet/Canvas. Pentru o versiune de producție cu volume mai mari sau scenarii multiple, stratul UAT poate fi transformat în PMTiles/vector tiles și afișat prin MapLibre.

Pentru deschidere directă puteți folosi și fișierul din directorul părinte `harta_interactiva_geografie_functionala_BNS_2024.html`. Acesta este aceeași aplicație autonomă.
