(function () {
  "use strict";

  const data = globalThis.EMBEDDED_DATA;
  const status = document.getElementById("data-status");
  if (!data || !globalThis.L) {
    status.className = "data-status error";
    status.textContent = !data ? "Datele GIS încorporate lipsesc" : "Leaflet nu s-a încărcat";
    return;
  }

  const REGION_COLOURS = {
    FR01: "#e76f51", FR02: "#457b9d", FR03: "#6a994e", FR04: "#7b6fd0",
    FR05: "#e9c46a", FR06: "#2a9d8f", FR07: "#d65db1"
  };
  const FUA_COLOURS = { "Chișinău": "#8d99ae", "Bălți": "#70b99a" };
  const regionNames = {
    FR01: "Chișinău–Centru", FR02: "Bălți–Nord", FR03: "Ungheni–Vest",
    FR04: "Soroca–Nord-Est", FR05: "Orhei–Centru-Nord", FR06: "Cahul–Sud-Vest", FR07: "Comrat–Sud-Est"
  };

  const fmt = new Intl.NumberFormat("ro-RO");
  const pct = value => value == null ? "—" : `${Number(value).toLocaleString("ro-RO", { maximumFractionDigits: 2 })}%`;
  const num = value => value == null ? "—" : fmt.format(Math.round(Number(value)));
  const decimal = (value, suffix = "") => value == null ? "—" : `${Number(value).toLocaleString("ro-RO", { maximumFractionDigits: 1 })}${suffix}`;
  const observedReason = reason => reason === "observed_15pct_to_centre" ? "observată ≥15%" : reason === "centre" ? "centru" : "modelată";

  let mode = "regions";
  let threshold = 15;
  let areaLayer;

  const map = L.map("map", { preferCanvas: true, zoomControl: true, minZoom: 6, maxZoom: 14 });
  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    opacity: 0.42,
    attribution: "© OpenStreetMap contributors"
  }).addTo(map);
  L.control.scale({ imperial: false, position: "bottomleft" }).addTo(map);
  map.fitBounds([[45.30, 26.45], [48.62, 30.35]], { padding: [18, 18] });

  function currentFuaName(properties) {
    return properties[`fua_${threshold}_name`];
  }

  function unitStyle(feature) {
    const p = feature.properties;
    if (mode === "regions") {
      return { color: "#ffffff", weight: 0.45, opacity: 0.9, fillColor: p.region_colour || "#cbd5db", fillOpacity: 0.8 };
    }
    if (mode === "micro") {
      return { color: "#ffffff", weight: 0.5, opacity: 0.92, fillColor: p.micro_colour || "#cbd5db", fillOpacity: 0.78 };
    }
    const name = currentFuaName(p);
    return { color: name ? "#34444b" : "#c8d2d7", weight: name ? 0.75 : 0.25, opacity: 0.85,
      fillColor: name ? FUA_COLOURS[name] : "#f7f8f8", fillOpacity: name ? 0.82 : 0.16 };
  }

  function aggregateForUnit(properties) {
    if (mode === "regions") {
      return data.regions.features.find(feature => feature.properties.functional_region_id === properties.functional_region_id);
    }
    if (mode === "micro") {
      return data.micro.features.find(feature => feature.properties.micro_id === properties.micro_id);
    }
    const name = currentFuaName(properties);
    return data[`fua${threshold}`].features.find(feature => feature.properties.fua_name === name);
  }

  function popupLabel(properties) {
    if (mode === "regions") return properties.functional_region_name;
    if (mode === "micro") return `${properties.micro_id} · ${properties.micro_centre}`;
    return currentFuaName(properties) ? `FUA ${currentFuaName(properties)}` : properties.unit_name;
  }

  function attachUnitInteraction(feature, layer) {
    layer.on("click", event => {
      const aggregate = aggregateForUnit(feature.properties);
      if (aggregate) showAggregate(aggregate);
      else showUnit(feature);
      layer.bindPopup(`<strong>${popupLabel(feature.properties)}</strong><span>Detalii în panoul lateral</span>`).openPopup(event.latlng);
    });
    layer.on("mouseover", () => layer.setStyle({ weight: 1.5, color: "#132a35" }));
    layer.on("mouseout", () => areaLayer && areaLayer.resetStyle(layer));
  }

  function bringGroupToFront(group) {
    group.eachLayer(layer => {
      if (typeof layer.bringToFront === "function") layer.bringToFront();
    });
    return group;
  }

  function redrawAreas() {
    if (areaLayer) map.removeLayer(areaLayer);
    areaLayer = L.geoJSON(data.units, {
      renderer: L.canvas({ padding: 0.35 }),
      style: unitStyle,
      onEachFeature: attachUnitInteraction
    }).addTo(map);
    bringGroupToFront(areaLayer);
    bringGroupToFront(pointUnitsLayer);
    if (document.getElementById("centres-toggle").checked) bringGroupToFront(centresLayer);
  }

  function centreRadius(feature) {
    return feature.properties.mandatory_regional_anchor ? 6 : 4;
  }

  const centresLayer = L.geoJSON(data.centres, {
    pointToLayer: (feature, latlng) => L.circleMarker(latlng, {
      radius: centreRadius(feature), color: "#ffffff", weight: 1.2, fillColor: "#072f49", fillOpacity: 1
    }),
    onEachFeature: (feature, layer) => layer.bindTooltip(`${feature.properties.centre_id} · ${feature.properties.unit_name}`)
  }).addTo(map);

  const pointUnitsLayer = L.geoJSON(data.pointUnits, {
    pointToLayer: (_feature, latlng) => L.circleMarker(latlng, {
      radius: 5, color: "#111827", weight: 1.5, fillColor: "#ffffff", fillOpacity: 1
    }),
    onEachFeature: (feature, layer) => layer.on("click", () => showUnit(feature))
  }).addTo(map);

  const flowsLayer = L.geoJSON(data.flows, {
    style: feature => ({
      color: feature.properties.same_functional_region ? "#273a46" : "#c1121f",
      opacity: 0.42,
      weight: Math.max(0.45, Math.min(4, Number(feature.properties.workers) / 500))
    }),
    onEachFeature: (feature, layer) => layer.bindTooltip(`${feature.properties.origin} → ${feature.properties.destination}: ${num(feature.properties.workers)}`)
  });

  const crossLayer = L.geoJSON(data.cross, {
    pointToLayer: (feature, latlng) => L.circleMarker(latlng, {
      radius: Math.max(3, Math.min(8, 2 + Number(feature.properties.left_bank_bender) / 25)),
      color: "#ffffff", weight: 1, fillColor: "#d62828", fillOpacity: 0.75
    }),
    onEachFeature: (feature, layer) => layer.bindTooltip(`${feature.properties.unit_name}: ${num(feature.properties.left_bank_bender)} lucrători`)
  });

  function setMode(next) {
    mode = next;
    document.querySelectorAll("[data-mode]").forEach(button => button.classList.toggle("active", button.dataset.mode === mode));
    document.getElementById("threshold-control").classList.toggle("hidden", mode !== "fua");
    redrawAreas(); updateKpis(); updateLegend(); resetPanel();
  }

  function setThreshold(next) {
    threshold = Number(next);
    document.querySelectorAll("[data-threshold]").forEach(button => button.classList.toggle("active", Number(button.dataset.threshold) === threshold));
    if (mode === "fua") setMode("fua");
  }

  function updateKpis() {
    const summary = data.summary;
    const areas = document.getElementById("kpi-areas");
    const areasLabel = document.getElementById("kpi-areas-label");
    const capture = document.getElementById("kpi-capture");
    const captureLabel = document.getElementById("kpi-capture-label");
    document.getElementById("kpi-units").textContent = fmt.format(summary.census_units);
    document.getElementById("kpi-pop").textContent = `${(summary.population_2024 / 1e6).toLocaleString("ro-RO", { maximumFractionDigits: 2 })} mil.`;
    if (mode === "regions") {
      areas.textContent = summary.functional_regions; areasLabel.textContent = "regiuni";
      capture.textContent = pct(summary.region_capture_pct); captureLabel.textContent = "navetism intercomunal reținut";
    } else if (mode === "micro") {
      areas.textContent = summary.micro_regions; areasLabel.textContent = "microregiuni";
      capture.textContent = pct(summary.micro_capture_pct); captureLabel.textContent = "navetism intercomunal reținut";
    } else {
      const f = summary.fua[String(threshold)];
      areas.textContent = f.areas; areasLabel.textContent = `FUA la ${threshold}%`;
      capture.textContent = fmt.format(f.units); captureLabel.textContent = "UAT incluse în FUA";
    }
  }

  function updateLegend() {
    const legend = document.getElementById("legend");
    let items;
    if (mode === "regions") items = Object.entries(regionNames).map(([id, name]) => [REGION_COLOURS[id], name]);
    else if (mode === "fua") items = Object.entries(FUA_COLOURS).map(([name, colour]) => [colour, `FUA ${name}`]);
    else items = [["#3b82f6", "microregiuni — culori categoriale"], ["#072f49", "centre microregionale"]];
    legend.innerHTML = `<h3>Legendă</h3>${items.map(([colour, label]) => `<div class="legend-item"><span class="swatch" style="background:${colour}"></span>${label}</div>`).join("")}`;
  }

  function resetPanel() {
    const title = mode === "regions" ? "Regiunile funcționale" : mode === "micro" ? "Microregiunile" : `FUA candidate — prag ${threshold}%`;
    document.getElementById("panel-kind").textContent = mode === "regions" ? "Nivel regional" : mode === "micro" ? "Nivel microregional" : "Arii urbane funcționale";
    document.getElementById("panel-title").textContent = title;
    document.getElementById("panel-content").innerHTML = mode === "fua"
      ? `<p>O UAT este inclusă dacă minimum ${threshold}% dintre rezidenții ocupați lucrează în nucleul Chișinău sau Bălți și zona este conectată teritorial la nucleu.</p><p>Acesta este un strat strict bazat pe navetism direct observat.</p>`
      : mode === "micro"
        ? `<p>32 de arii cotidiene construite din navetism observat, timp/distanță rutieră, centralitatea serviciilor și contiguitate.</p><p>Atribuirile care nu trec pragul de 15% sunt marcate ca modelate în fișa UAT.</p>`
        : `<p>Șapte regiuni construite din fluxurile bidirecționale agregate la microregiuni. Raioanele nu au fost criteriu sau barieră.</p><p>Dimensiunile inegale reflectă centralizarea fluxurilor; nu s-a impus echilibru administrativ.</p>`;
  }

  function showAggregate(feature) {
    const p = feature.properties;
    if (mode === "regions") {
      document.getElementById("panel-kind").textContent = p.functional_region_id;
      document.getElementById("panel-title").textContent = p.functional_region_name;
      document.getElementById("panel-content").innerHTML = `<dl>
        <dt>Centru</dt><dd>${p.functional_region_centre}</dd><dt>UAT</dt><dd>${num(p.units)}</dd>
        <dt>Populație 2024</dt><dd>${num(p.population_2024)}</dd><dt>Autocontenție rezidenți</dt><dd>${pct(p.resident_self_containment_pct)}</dd>
        <dt>Autocontenție locuri de muncă</dt><dd>${pct(p.job_self_containment_pct)}</dd><dt>Navetism intercomunal reținut</dt><dd>${pct(p.intercommunal_capture_pct)}</dd>
        <dt>Lucrători spre stânga Nistrului/Bender</dt><dd>${num(p.left_bank_bender_workers)}</dd></dl>`;
    } else if (mode === "micro") {
      document.getElementById("panel-kind").textContent = p.micro_id;
      document.getElementById("panel-title").textContent = p.micro_centre;
      document.getElementById("panel-content").innerHTML = `<dl>
        <dt>UAT</dt><dd>${num(p.units)}</dd><dt>Populație 2024</dt><dd>${num(p.population_2024)}</dd>
        <dt>Autocontenție rezidenți</dt><dd>${pct(p.resident_self_containment_pct)}</dd><dt>Autocontenție locuri de muncă</dt><dd>${pct(p.job_self_containment_pct)}</dd>
        <dt>Navetism intercomunal reținut</dt><dd>${pct(p.intercommunal_capture_pct)}</dd></dl>`;
    } else {
      const f = data.summary.fua[String(threshold)];
      document.getElementById("panel-kind").textContent = `Prag ${threshold}%`;
      document.getElementById("panel-title").textContent = `FUA ${p.fua_name}`;
      document.getElementById("panel-content").innerHTML = `<dl><dt>Prag</dt><dd>${threshold}%</dd><dt>Suprafață</dt><dd>${decimal(p.area_km2, " km²")}</dd></dl><p>La acest prag, cele două FUA includ în total ${num(f.units)} UAT și ${num(f.population)} locuitori.</p>`;
    }
  }

  function showUnit(feature) {
    const p = feature.properties;
    document.getElementById("panel-kind").textContent = `UAT · ${p.cuatm}`;
    document.getElementById("panel-title").textContent = p.unit_name;
    document.getElementById("panel-content").innerHTML = `<p><span class="badge">${observedReason(p.micro_assignment_reason)}</span></p><dl>
      <dt>Raion — numai referință</dt><dd>${p.district}</dd><dt>Populație 2024</dt><dd>${num(p.population_2024)}</dd>
      <dt>Microregiune</dt><dd>${p.micro_id}</dd><dt>Centru</dt><dd>${p.micro_centre}</dd>
      <dt>Pondere spre centru</dt><dd>${pct(Number(p.commuting_share_to_centre) * 100)}</dd>
      <dt>Timp modelat</dt><dd>${decimal(p.time_to_micro_min, " min")}</dd><dt>Distanță rutieră</dt><dd>${decimal(p.distance_to_micro_km, " km")}</dd>
      <dt>Metoda traseului</dt><dd>${p.route_method === "fastest_osm_route" ? "rută OSM" : "aproximare"}</dd>
      <dt>Regiune funcțională</dt><dd>${p.functional_region_name}</dd><dt>FUA 15%</dt><dd>${p.fua_15_name || "în afară"}</dd>
    </dl>`;
  }

  const allUnitFeatures = [...data.units.features, ...data.pointUnits.features];
  const datalist = document.getElementById("uat-list");
  datalist.innerHTML = allUnitFeatures.map(feature => `<option value="${feature.properties.unit_name}">${feature.properties.cuatm}</option>`).join("");

  function searchUnit(value) {
    const key = value.trim().toLocaleLowerCase("ro");
    if (!key) return;
    const feature = allUnitFeatures.find(f => f.properties.cuatm === value.trim() || f.properties.unit_name.toLocaleLowerCase("ro") === key)
      || allUnitFeatures.find(f => f.properties.unit_name.toLocaleLowerCase("ro").includes(key));
    if (!feature) return;
    const layer = L.geoJSON(feature);
    const bounds = layer.getBounds();
    if (bounds.isValid() && bounds.getNorthEast().equals(bounds.getSouthWest())) map.setView(bounds.getCenter(), 11);
    else if (bounds.isValid()) map.fitBounds(bounds, { padding: [70, 70], maxZoom: 11 });
    showUnit(feature);
  }

  document.querySelectorAll("[data-mode]").forEach(button => button.addEventListener("click", () => setMode(button.dataset.mode)));
  document.querySelectorAll("[data-threshold]").forEach(button => button.addEventListener("click", () => setThreshold(button.dataset.threshold)));
  document.getElementById("centres-toggle").addEventListener("change", event => event.target.checked ? bringGroupToFront(centresLayer.addTo(map)) : map.removeLayer(centresLayer));
  document.getElementById("flows-toggle").addEventListener("change", event => event.target.checked ? bringGroupToFront(flowsLayer.addTo(map)) : map.removeLayer(flowsLayer));
  document.getElementById("cross-toggle").addEventListener("change", event => event.target.checked ? bringGroupToFront(crossLayer.addTo(map)) : map.removeLayer(crossLayer));
  document.getElementById("panel-reset").addEventListener("click", resetPanel);
  document.getElementById("search").addEventListener("change", event => searchUnit(event.target.value));
  document.getElementById("search").addEventListener("keydown", event => { if (event.key === "Enter") searchUnit(event.target.value); });

  redrawAreas(); updateKpis(); updateLegend(); resetPanel();
  status.className = "data-status ready";
  status.textContent = "Straturi GIS vizibile · 897 UAT";
  window.setTimeout(() => map.invalidateSize(), 100);
}());
