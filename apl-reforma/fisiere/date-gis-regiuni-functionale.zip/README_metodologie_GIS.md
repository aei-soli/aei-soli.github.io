# Moldova functional economic geography - first working draft

This package is an exploratory, reproducible GIS model of functional geography in the Republic of Moldova. It is designed for testing and refinement, not for legal or administrative use. The analytical boundaries are **modelled accessibility catchments**, not observed commuting, patient, student, freight, or transaction flows.

## Main deliverables

- `moldova_functional_geography_draft.gpkg` - master GeoPackage in EPSG:32635 with eight layers.
- `moldova_functional_geography.qgs` - portable QGIS project referencing the GeoPackage by relative path.
- `candidate_metro_fua.geojson`, `micro_regions.geojson`, `functional_regions.geojson`, `candidate_centres.geojson` - WGS84 web/GIS exports.
- `local_unit_assignments.csv` - unit-level population, service counts, assignments, and modelled travel times.
- `moldova_functional_geography_overview.png` and `.pdf` - static three-panel overview.
- `build_functional_geography.py` - complete reproducible builder.
- `validation_metrics.json` - headline QA counts.
- `estimated_fua_2024_2026.geojson` - partial contemporary eFUA update anchored to GHSL UCDB R2024A urban cores.
- `ghsl_urban_centres_r2024a.geojson` - the five current GHSL urban-centre polygons in Moldova.
- `moldova_updated_estimated_fua.png` and `.pdf` - map of the partial contemporary update.
- `build_updated_fua.py` - reproducible contemporary-update builder.
- `updated_micro_regions.geojson` and `updated_functional_regions.geojson` - revised lower and upper functional systems using mandatory GHSL R2024A cores.
- `updated_centres_r2024a.geojson` - combined GHSL-core and Moldova-specific local-centre hierarchy.
- `updated_region_assignments.csv` - auditable base-unit assignments and travel-time estimates.
- `moldova_updated_micro_and_functional_regions.png` and `.pdf` - revised two-panel map.
- `build_updated_regions.py` - reproducible revised-region builder.
- `right_bank_micro_regions.geojson` and `right_bank_functional_regions.geojson` - preferred scenario excluding the Transnistrian administrative unit and Bender.
- `right_bank_excluded_units.geojson` - explicit mask of units withheld from assignment.
- `right_bank_assignments.csv` - auditable assignments and travel-time estimates for the included scope.
- `moldova_right_bank_functional_geography.png` and `.pdf` - right-bank scenario map.
- `build_right_bank_scenario.py` - reproducible right-bank scenario builder.

## GeoPackage layers

| Layer | Meaning | Evidence status |
|---|---|---|
| `local_units_model` | OSM admin-level-8 local-government polygons with census joins and all assignments | Mixed observed/modelled |
| `candidate_centres` | Population-and-service centrality candidates | Modelled from observed inputs |
| `candidate_metro_fua` | 45-minute candidate metropolitan catchments around centres with >=18,000 joined census residents | Modelled inference |
| `micro_regions` | Nearest-centre road-accessibility catchments | Modelled inference |
| `functional_regions` | Seven larger anchor-centre accessibility regions | Modelled inference |
| `ghsl_fua_2015` | Moldova extract of the EC/JRC global FUA product | Published external model (2015) |
| `osm_major_roads` | Trunk, primary, and secondary road context | Observed/crowdsourced OSM |
| `admin2_context` | District context from OSM; not used as target functional boundaries | Observed/crowdsourced OSM |
| `ghsl_urban_centres_r2024a` | Five GHSL UCDB R2024A urban cores: Chișinău, Bălți, Bender, Tiraspol, and Rybnitsa | Published GHSL model |
| `estimated_fua_2024_2026` | 45-minute catchments anchored on those updated cores | Modelled inference |
| `estimated_fua_assignments` | Base units included in the updated-core catchments | Modelled inference |
| `updated_centres_r2024a` | Combined GHSL-core and local population/service centres | Mixed published/modelled |
| `updated_micro_regions` | Revised nearest-centre everyday accessibility catchments | Modelled inference |
| `updated_functional_regions` | Nine proposed larger systems, including two east-bank systems | Modelled inference |
| `updated_region_assignments` | Base-unit assignments and modelled travel times for both revised levels | Modelled inference |
| `right_bank_centres` | Centre hierarchy retained inside the government-administered/right-bank scope | Mixed published/modelled |
| `right_bank_micro_regions` | Revised micro-regions with an eastern territorial barrier | Modelled inference |
| `right_bank_functional_regions` | Seven-region right-bank proposal | Modelled inference |
| `right_bank_assignments` | Included base-unit assignments and travel times | Modelled inference |
| `right_bank_excluded_units` | Transnistrian administrative unit and Bender, withheld from assignment | Explicit scope mask |

## Sources and dates

1. **National Bureau of Statistics of Moldova, final 2024 Population and Housing Census locality tables.** Reference date: 8 April 2024; published 2025. Source workbook: <https://statistica.gov.md/files/files/ComPresa/Recensamant/2024/Ro/Anexa_Localitati_RPL2024.xlsx>. The census reports 2,409,207 usual residents in 1,525 enumerated localities. It excludes 157 localities outside de facto constitutional-authority control.
2. **OpenStreetMap via Geofabrik Moldova extract.** Snapshot dated 4 August 2026, downloaded 5 August 2026: <https://download.geofabrik.de/europe/moldova.html>. Used for admin-level-8 polygons, roads, and service POIs. OSM data are licensed under ODbL 1.0: <https://opendatacommons.org/licenses/odbl/1-0/>.
3. **European Commission Joint Research Centre, GHS-FUA R2019A.** Functional Urban Areas for 2015, World Mollweide 1 km product: <https://human-settlement.emergency.copernicus.eu/ghs_fua.php>. DOI: <https://doi.org/10.2905/347F0337-F2DA-4592-87B3-E25975EC2C95>.
4. **European Commission Joint Research Centre, GHS-UCDB R2024A V1.2.** Contemporary urban-centre polygons and attributes: <https://human-settlement.emergency.copernicus.eu/ucdb2024Overview.php>. The five Moldova cores are used as anchors, not treated as FUAs themselves.

GHSL population and built-up products were reviewed as candidate inputs. The final draft uses the official 2024 locality census for population and OSM settlement/service/road geometry for current local modelling; the older GHSL FUA is retained as a separate benchmark layer. A later raster refinement can add GHS-POP/GHS-BUILT-S tiles without changing the package schema.

## Method

### 1. Locality/base geography

The base units are OSM `admin_level=8` polygons, approximating Moldova's first-level cities/communes rather than raions. Census commune/city rows are joined within their district by normalized Romanian name, with conservative fuzzy matching and a one-to-one constraint. The CUATM code, join score, and `census_status` remain in the output for audit.

### 2. Centre centrality

For each base unit, the model counts OSM education, health, retail/finance, and civic POIs. Candidate centrality is a transparent combination of log population and log service counts. Potential centres require at least 3,500 joined residents or 18 mapped services and are greedily spaced by 16 km. The top 38 retained centres form the micro-regional system.

### 3. Accessibility

Road segments classified as trunk, primary, secondary, tertiary, unclassified, residential, or living street form an undirected graph. Time weights use mapped plausible `maxspeed` values or class defaults (90/80/70/60/45/35/20 km/h). Each base-unit representative point is snapped to the closest road node. Disconnected cases fall back to straight-line time at 45 km/h.

This is a **private-car accessibility proxy**. It does not model congestion, border controls, road condition, public transport, river crossings in detail, directionality, or observed trips.

### 4. Three functional layers

- **Candidate metropolitan/FUA areas:** centres with at least 18,000 joined 2024 residents; units within 45 road minutes are assigned using a population-over-time-squared gravity score. Seven candidates result: Chișinău, Bălți, Ungheni, Cahul, Comrat, Soroca, and Orhei.
- **Micro-regions:** every base unit is assigned to the closest of 38 candidate centres by modelled road time.
- **Functional economic regions:** every base unit is assigned to one of seven larger anchors: Chișinău, Bălți, Cahul, Comrat, Ungheni, Soroca, or Orhei.

### 5. Partial contemporary FUA update

The additional `estimated_fua_2024_2026` layer replaces the old 2015 core reference with the five Moldova urban centres published in GHSL UCDB R2024A V1.2: Chișinău, Bălți, Bender, Tiraspol, and Rybnitsa. Base units are assigned by population-weighted road accessibility where modelled travel time is no more than 45 minutes. The 2024 census supplies population where available; the 2026 OSM snapshot supplies roads. These are experimental estimated FUAs, not observed commuting zones. Smaller centres such as Cahul, Comrat, Ungheni, Soroca, and Orhei fall below the GHSL urban-centre threshold and therefore remain only in the broader Moldova-specific candidate layer.

### 6. Updated micro-regions and functional economic regions

The revised micro-region model makes all five GHSL R2024A urban cores mandatory centres. It retains Moldova-specific population/service centres unless they fall within 16 km of a GHSL core, preventing suburban or proxy centres from duplicating Chișinău, Bălți, Bender, Tiraspol, or Rybnitsa. The result is 37 micro-regional accessibility catchments.

The revised larger geography contains nine proposed systems: Chișinău–Centre, Bălți–North, Ungheni–West, Soroca–North-East, Orhei–Centre-North, Cahul–South-West, Comrat–South-East, Tiraspol–Bender East, and Rybnitsa–North-East Bank. Tiraspol and Bender are treated as a single polycentric anchor. Assignment uses minimum modelled road time to the relevant anchor or anchor pair. These names describe model outputs and are not official territorial designations.

### 7. Preferred right-bank/government-administered scenario

Because no observed commuting, mobile-movement, freight, transaction, education, or patient-flow matrix was available to demonstrate integration across the Nistru, the preferred scenario does not infer it from physical road proximity. The Transnistrian administrative unit and Bender are excluded as anchors and destinations, and graph nodes in the excluded territory are removed so modelled routes cannot traverse it. Government-administered Dubăsari localities remain within scope; therefore “right bank” is used in the common institutional sense rather than as a perfectly literal river-side classification.

This scenario contains 904 assigned base polygons, 81 explicitly excluded polygons, 34 micro-regions, and seven larger systems: Chișinău–Centre, Bălți–North, Ungheni–West, Soroca–North-East, Orhei–Centre-North, Cahul–South-West, and Comrat–South-East. Cross-river areas should be added later only through a separately documented observed-flow test.

## Validation summary

- 985 OSM admin-level-8 polygons processed.
- 886 polygons matched one-to-one to a 2024 census city/commune row.
- 2,397,494 census residents joined (99.51% of the national enumerated total); the residual reflects unmatched boundary/name structures.
- 38 micro-regions, 7 metropolitan candidates, 7 provisional economic regions, and 5 intersecting GHSL FUA features.
- The package intentionally leaves `population_2024` null where census evidence is absent or a conservative join was not possible.

## Important limitations

- No locality-to-locality commuting matrix was publicly available in the source set used here. None of the new functional boundaries should be described as observed labour-market areas.
- OSM completeness varies spatially. Service centrality can be biased toward better-mapped places, especially on the left bank of the Nistru.
- OSM admin-level-8 is not an official cadastral boundary source. Before policy use, replace or validate it against an authoritative CUATM/local-government boundary layer.
- The census/non-census territorial asymmetry is material. Do not compare regional totals as if coverage were uniform.
- The FUA threshold and all travel-time/speed parameters are deliberately exposed for sensitivity testing.

## Reproduction

Create a Python environment with `geopandas`, `pyogrio`, `shapely`, `networkx`, `scipy`, `matplotlib`, `pandas`, and `openpyxl`; place the source files in `work/data/raw` using the paths in the script; then run:

```bash
python build_functional_geography.py
```

The script overwrites the generated package deterministically from the downloaded snapshots. For a policy-grade second version, the highest-value additions are observed commuting/education/health flows, an authoritative CUATM polygon layer, public-transport travel times, and sensitivity ensembles for centre thresholds and travel-time cutoffs.
